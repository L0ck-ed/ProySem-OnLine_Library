<?php

use App\Helpers\Session;
use App\Config\Config;

$error = Session::getFlash('error');
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - MyProjectBibliotecaV2</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?= Config::assetsUrl() ?>/CSS/style.css?v=modern-library-1">
</head>

<body class="login-body">

<div class="login-container">
    <div class="card-login">
        <div class="text-center mb-4">
            <i class="fa-solid fa-book-open-reader logo"></i>
            <h2>MyProjectBiblioteca</h2>
            <p>Sistema de Gestión Bibliotecaria</p>
        </div>

        <?php if ($error): ?>
            <div class="alert alert-danger text-center">
                <?= $error ?>
            </div>
        <?php endif; ?>

        <form
            method="POST"
            action="<?= Config::url('portal/login') ?>"
        >
            <input
                type="text"
                name="credencial"
                placeholder="Usuario, correo o CIP"
                value="<?= htmlspecialchars(
                    (string) ($credencialAnterior ?? ''),
                    ENT_QUOTES,
                    'UTF-8',
                ) ?>"
                required
            >

            <input
                type="password"
                name="clave"
                placeholder="Contraseña"
                required
            >

            <button type="submit">
                Iniciar sesión
            </button>
        </form>

        <small class="d-block text-center mt-3 text-muted">
            Usuario inicial: admin / root2514
        </small>
    </div>
</div>

</body>
</html>
